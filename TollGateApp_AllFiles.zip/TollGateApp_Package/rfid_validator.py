"""
NC(V) Level 2 - Coding and Robotics ISAT
Subtask 3: Python program - String manipulation
Toll Gate RFID Tag Validator

-----------------------------------------------------------------------------
NOTE ON THE VALIDATION RULE
-----------------------------------------------------------------------------
The uploaded question paper is cut off exactly where it defines the required
RFID tag FORMAT, so the exact rule your paper specifies is not available here.

This program uses a common format for these NC(V) papers so you can see the
full string-manipulation technique in action:

    A valid RFID tag must be exactly 8 characters long, made up of:
      - 2 uppercase letters, followed by
      - 6 digits
    Example of a VALID tag   : AB123456
    Example of an INVALID tag: A1234567   (only 1 letter)
                                AB12345    (only 5 digits)
                                ab123456   (lowercase letters)

If your actual paper specifies a different format (different length, a
different number of letters/digits, a dash in the middle, etc.), find the
line "def is_valid_rfid(tag):" below and adjust the checks - the comments
explain exactly what each line is doing so you can adapt it.
-----------------------------------------------------------------------------
"""


def is_valid_rfid(tag):
    """
    Returns True if 'tag' matches the required RFID format, False otherwise.

    Required format used in this example:
        - Total length = 8 characters
        - First 2 characters = uppercase letters (A-Z)
        - Last 6 characters  = digits (0-9)
    """

    # Rule 1: the tag must be exactly 8 characters long
    if len(tag) != 8:
        return False

    # Split the tag into its two parts using string slicing
    letter_part = tag[0:2]   # first 2 characters
    digit_part = tag[2:8]    # remaining 6 characters

    # Rule 2: the letter part must contain ONLY uppercase letters
    if not letter_part.isalpha():
        return False
    if not letter_part.isupper():
        return False

    # Rule 3: the digit part must contain ONLY digits
    if not digit_part.isdigit():
        return False

    # If every rule passed, the tag is valid
    return True


def main():
    print("=== Toll Gate RFID Tag Validator ===")
    rfid_tag = input("Enter the RFID tag: ")

    # .strip() removes any accidental leading/trailing spaces from input
    rfid_tag = rfid_tag.strip()

    if is_valid_rfid(rfid_tag):
        print("RFID tag is valid.")
    else:
        print("RFID tag is invalid.")


if __name__ == "__main__":
    main()
